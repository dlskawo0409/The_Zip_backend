-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema ssafyhome
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema ssafyhome
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ssafyhome` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ;
USE `ssafyhome` ;

-- -----------------------------------------------------
-- Table `ssafyhome`.`dormitory`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`dormitory` (
  `dormitory_id` BIGINT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(20) NULL DEFAULT NULL,
  `room_number` VARCHAR(15) NULL DEFAULT NULL,
  `room_count` BIGINT NULL DEFAULT NULL,
  `capacity` BIGINT NULL DEFAULT NULL,
  `deposit` BIGINT NULL DEFAULT NULL,
  `rent` BIGINT NULL DEFAULT NULL,
  `yearly_rent` BIGINT NULL DEFAULT NULL,
  `maintenance` BIGINT NULL DEFAULT NULL,
  `dormitory_kind` VARCHAR(10) NULL DEFAULT NULL,
  `college_id` BIGINT NULL DEFAULT NULL,
  `sum` BIGINT NULL DEFAULT NULL,
  PRIMARY KEY (`dormitory_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 148
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`amenity`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`amenity` (
  `amenity_id` BIGINT NOT NULL AUTO_INCREMENT,
  `dormitory_id` BIGINT NULL DEFAULT NULL,
  `name` VARCHAR(15) NULL DEFAULT NULL,
  PRIMARY KEY (`amenity_id`),
  INDEX `dormitory_id` (`dormitory_id` ASC) VISIBLE,
  CONSTRAINT `amenity_ibfk_1`
    FOREIGN KEY (`dormitory_id`)
    REFERENCES `ssafyhome`.`dormitory` (`dormitory_id`)
    ON DELETE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`apartment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`apartment` (
  `apt_id` INT NOT NULL AUTO_INCREMENT,
  `apt_seq` VARCHAR(45) NULL DEFAULT NULL,
  `name` VARCHAR(45) NULL DEFAULT NULL,
  `dong_code` VARCHAR(45) NULL DEFAULT NULL,
  `floor` INT NULL DEFAULT NULL,
  `size` FLOAT NULL DEFAULT NULL,
  `price` INT NULL DEFAULT NULL,
  `latitude` VARCHAR(45) NULL DEFAULT NULL,
  `longitude` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`apt_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 28822453
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`board`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`board` (
  `board_id` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `content` TEXT NOT NULL,
  `author` VARCHAR(100) NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `views` INT NULL DEFAULT '0',
  PRIMARY KEY (`board_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 34
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`charter`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`charter` (
  `charter_id` BIGINT NOT NULL AUTO_INCREMENT,
  `charter_kind` VARCHAR(5) NOT NULL,
  `floor` VARCHAR(3) NOT NULL,
  `deal_year` INT NULL DEFAULT NULL,
  `deal_month` INT NULL DEFAULT NULL,
  `deal_day` INT NULL DEFAULT NULL,
  `deposit` INT NULL DEFAULT NULL,
  `rent` INT NULL DEFAULT NULL,
  `name` VARCHAR(50) NULL DEFAULT NULL,
  `size` FLOAT NULL DEFAULT NULL,
  `construction_year` INT NULL DEFAULT NULL,
  `building_use` VARCHAR(10) NULL DEFAULT NULL,
  `member_id` BIGINT NULL DEFAULT NULL,
  `charter_gu` VARCHAR(20) NULL DEFAULT NULL,
  `charter_dong` VARCHAR(20) NULL DEFAULT NULL,
  `bonbun` INT NULL DEFAULT NULL,
  `bubun` INT NULL DEFAULT NULL,
  `pre_code` VARCHAR(5) NOT NULL,
  `post_code` VARCHAR(5) NOT NULL,
  PRIMARY KEY (`charter_id`),
  FULLTEXT INDEX `name_fulltext_idx` (`name`) WITH PARSER `ngram` VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 412463
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`college`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`college` (
  `college_id` INT NOT NULL AUTO_INCREMENT,
  `college_name` VARCHAR(255) NULL DEFAULT NULL,
  `college_english_name` VARCHAR(255) NULL DEFAULT NULL,
  `branch_type` VARCHAR(255) NULL DEFAULT NULL,
  `region_name` VARCHAR(255) NULL DEFAULT NULL,
  `road_address` VARCHAR(255) NULL DEFAULT NULL,
  `homepage` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`college_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 400
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`comment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`comment` (
  `comment_id` INT NOT NULL AUTO_INCREMENT,
  `board_id` INT NOT NULL,
  `member_id` BIGINT NOT NULL,
  `content` TEXT NOT NULL,
  `author` VARCHAR(100) NOT NULL,
  `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `ideleted_at` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`comment_id`),
  INDEX `board_id` (`board_id` ASC) VISIBLE,
  CONSTRAINT `comment_ibfk_1`
    FOREIGN KEY (`board_id`)
    REFERENCES `ssafyhome`.`board` (`board_id`)
    ON DELETE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 37
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`dongcodes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`dongcodes` (
  `dong_code` VARCHAR(10) NOT NULL,
  `sido_name` VARCHAR(30) NULL DEFAULT NULL,
  `gugun_name` VARCHAR(30) NULL DEFAULT NULL,
  `dong_name` VARCHAR(30) NULL DEFAULT NULL,
  PRIMARY KEY (`dong_code`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`houseinfos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`houseinfos` (
  `apt_seq` VARCHAR(20) NOT NULL,
  `sgg_cd` VARCHAR(5) NULL DEFAULT NULL,
  `umd_cd` VARCHAR(5) NULL DEFAULT NULL,
  `umd_nm` VARCHAR(20) NULL DEFAULT NULL,
  `jibun` VARCHAR(10) NULL DEFAULT NULL,
  `road_nm_sgg_cd` VARCHAR(5) NULL DEFAULT NULL,
  `road_nm` VARCHAR(20) NULL DEFAULT NULL,
  `road_nm_bonbun` VARCHAR(10) NULL DEFAULT NULL,
  `road_nm_bubun` VARCHAR(10) NULL DEFAULT NULL,
  `apt_nm` VARCHAR(40) NULL DEFAULT NULL,
  `build_year` INT NULL DEFAULT NULL,
  `latitude` VARCHAR(45) NULL DEFAULT NULL,
  `longitude` VARCHAR(45) NULL DEFAULT NULL,
  `floor` VARCHAR(3) NULL DEFAULT NULL,
  `exclu_use_ar` DECIMAL(7,2) NULL DEFAULT NULL,
  `deal_amount` VARCHAR(10) NULL DEFAULT NULL,
  PRIMARY KEY (`apt_seq`),
  FULLTEXT INDEX `apt_nm_fulltext_idx` (`apt_nm`) WITH PARSER `ngram` VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`housedeals`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`housedeals` (
  `no` INT NOT NULL AUTO_INCREMENT,
  `apt_seq` VARCHAR(20) NULL DEFAULT NULL,
  `apt_dong` VARCHAR(40) NULL DEFAULT NULL,
  `floor` VARCHAR(3) NULL DEFAULT NULL,
  `deal_year` INT NULL DEFAULT NULL,
  `deal_month` INT NULL DEFAULT NULL,
  `deal_day` INT NULL DEFAULT NULL,
  `exclu_use_ar` DECIMAL(7,2) NULL DEFAULT NULL,
  `deal_amount` VARCHAR(10) NULL DEFAULT NULL,
  PRIMARY KEY (`no`),
  INDEX `idx_housedeals_aptseq_dealdate` (`apt_seq` ASC, `deal_year` DESC, `deal_month` DESC, `deal_day` DESC) VISIBLE,
  INDEX `idx_deal_date` (`deal_year` ASC, `deal_month` ASC, `deal_day` ASC) VISIBLE,
  INDEX `idx_housedeals_apt_seq` (`apt_seq` ASC) VISIBLE,
  INDEX `idx_housedeals_apt_seq_deal_date` (`apt_seq` ASC, `deal_year` DESC, `deal_month` DESC, `deal_day` DESC) VISIBLE,
  CONSTRAINT `apt_seq_to_house_info`
    FOREIGN KEY (`apt_seq`)
    REFERENCES `ssafyhome`.`houseinfos` (`apt_seq`))
ENGINE = InnoDB
AUTO_INCREMENT = 7084512
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`image`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`image` (
  `image_id` BIGINT NOT NULL AUTO_INCREMENT,
  `image_url` VARCHAR(255) NULL DEFAULT NULL,
  `image_type` VARCHAR(10) NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reference_id` VARCHAR(20) NULL DEFAULT NULL,
  PRIMARY KEY (`image_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 965868
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`member`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`member` (
  `member_id` BIGINT NOT NULL AUTO_INCREMENT,
  `user_name` VARCHAR(255) NULL DEFAULT NULL,
  `password` VARCHAR(60) NULL DEFAULT NULL,
  `nickname` VARCHAR(20) NULL DEFAULT NULL,
  `gender` VARCHAR(10) NULL DEFAULT NULL,
  `isBlocked` VARCHAR(3) NULL DEFAULT 'F',
  `role` VARCHAR(10) NULL DEFAULT NULL,
  `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` DATETIME NULL DEFAULT NULL,
  `college_id` INT NULL DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  INDEX `fk_college_id` (`college_id` ASC) VISIBLE,
  CONSTRAINT `fk_college_id`
    FOREIGN KEY (`college_id`)
    REFERENCES `ssafyhome`.`college` (`college_id`)
    ON DELETE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 15
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`interest_area`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`interest_area` (
  `interest_area_id` BIGINT NOT NULL AUTO_INCREMENT,
  `member_id` BIGINT NULL DEFAULT NULL,
  `dong_code` VARCHAR(10) NULL DEFAULT NULL,
  `name` VARCHAR(25) NULL DEFAULT NULL,
  PRIMARY KEY (`interest_area_id`),
  INDEX `member_id` (`member_id` ASC) VISIBLE,
  CONSTRAINT `interest_area_ibfk_1`
    FOREIGN KEY (`member_id`)
    REFERENCES `ssafyhome`.`member` (`member_id`)
    ON DELETE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`interest_charter`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`interest_charter` (
  `interest_charter_id` BIGINT NOT NULL AUTO_INCREMENT,
  `member_id` BIGINT NULL DEFAULT NULL,
  `charter_id` BIGINT NULL DEFAULT NULL,
  PRIMARY KEY (`interest_charter_id`),
  INDEX `member_id` (`member_id` ASC) VISIBLE,
  CONSTRAINT `interest_charter_ibfk_1`
    FOREIGN KEY (`member_id`)
    REFERENCES `ssafyhome`.`member` (`member_id`)
    ON DELETE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 82
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`interest_house`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`interest_house` (
  `interest_house_id` BIGINT NOT NULL AUTO_INCREMENT,
  `member_id` BIGINT NULL DEFAULT NULL,
  `apt_seq` VARCHAR(20) CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_0900_ai_ci' NULL DEFAULT NULL,
  PRIMARY KEY (`interest_house_id`),
  INDEX `member_id` (`member_id` ASC) VISIBLE,
  INDEX `idx_apt_seq` (`apt_seq` ASC) VISIBLE,
  CONSTRAINT `interest_house_ibfk_1`
    FOREIGN KEY (`member_id`)
    REFERENCES `ssafyhome`.`member` (`member_id`)
    ON DELETE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 37
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`refresh`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`refresh` (
  `refresh_id` BIGINT NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(255) NOT NULL,
  `refresh` VARCHAR(512) NOT NULL,
  `expiration` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`refresh_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 296
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `ssafyhome`.`way_length`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`way_length` (
  `way_length_id` BIGINT NOT NULL AUTO_INCREMENT,
  `apartment_id` VARCHAR(50) NOT NULL,
  `amenity_id` BIGINT NOT NULL,
  `distance` FLOAT NULL DEFAULT NULL,
  PRIMARY KEY (`way_length_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

USE `ssafyhome` ;

-- -----------------------------------------------------
-- Placeholder table for view `ssafyhome`.`apartment_view`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssafyhome`.`apartment_view` (`apt_seq` INT, `name` INT, `dong_code` INT, `floor` INT, `size` INT, `price` INT, `latitude` INT, `longitude` INT);

-- -----------------------------------------------------
-- View `ssafyhome`.`apartment_view`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ssafyhome`.`apartment_view`;
USE `ssafyhome`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`ssafy`@`%` SQL SECURITY DEFINER VIEW `ssafyhome`.`apartment_view` AS select `hinfo`.`apt_seq` AS `apt_seq`,`hinfo`.`apt_nm` AS `name`,concat(`hinfo`.`sgg_cd`,`hinfo`.`umd_cd`) AS `dong_code`,(case when (trim(`hdeal`.`floor`) = '') then NULL else cast(`hdeal`.`floor` as signed) end) AS `floor`,`hdeal`.`exclu_use_ar` AS `size`,(replace(`hdeal`.`deal_amount`,',','') + 0) AS `price`,`hinfo`.`latitude` AS `latitude`,`hinfo`.`longitude` AS `longitude` from (`ssafyhome`.`houseinfos` `hinfo` join `ssafyhome`.`housedeals` `hdeal` on((`hinfo`.`apt_seq` = `hdeal`.`apt_seq`)));

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
